# Code Citations

## License: MIT
https://github.com/ekokratos/reshipi-book/blob/b5d9cfff0fe0d577a1dd63099cf7679fcc95dd25/lib/features/recipe_edit/widgets/recipe_bottom_sheet.dart

```
EdgeIn
```


## License: MIT
https://github.com/ekokratos/reshipi-book/blob/b5d9cfff0fe0d577a1dd63099cf7679fcc95dd25/lib/features/recipe_edit/widgets/recipe_bottom_sheet.dart

```
EdgeInsets.all
```


## License: MIT
https://github.com/ekokratos/reshipi-book/blob/b5d9cfff0fe0d577a1dd63099cf7679fcc95dd25/lib/features/recipe_edit/widgets/recipe_bottom_sheet.dart

```
EdgeInsets.all(20),
            
```


## License: unknown
https://github.com/troublecatcher/basketball/blob/f55c61c55e0793268c37ebcdf13a47d862ebf3c6/lib/screens/notes.dart

```
EdgeInsets.all(20),
            
```


## License: MIT
https://github.com/ekokratos/reshipi-book/blob/b5d9cfff0fe0d577a1dd63099cf7679fcc95dd25/lib/features/recipe_edit/widgets/recipe_bottom_sheet.dart

```
EdgeInsets.all(20),
            decoration: const
```


## License: unknown
https://github.com/troublecatcher/basketball/blob/f55c61c55e0793268c37ebcdf13a47d862ebf3c6/lib/screens/notes.dart

```
EdgeInsets.all(20),
            decoration: const
```


## License: MIT
https://github.com/ekokratos/reshipi-book/blob/b5d9cfff0fe0d577a1dd63099cf7679fcc95dd25/lib/features/recipe_edit/widgets/recipe_bottom_sheet.dart

```
EdgeInsets.all(20),
            decoration: const BoxDecoration(
```


## License: unknown
https://github.com/troublecatcher/basketball/blob/f55c61c55e0793268c37ebcdf13a47d862ebf3c6/lib/screens/notes.dart

```
EdgeInsets.all(20),
            decoration: const BoxDecoration(
```


## License: MIT
https://github.com/ekokratos/reshipi-book/blob/b5d9cfff0fe0d577a1dd63099cf7679fcc95dd25/lib/features/recipe_edit/widgets/recipe_bottom_sheet.dart

```
EdgeInsets.all(20),
            decoration: const BoxDecoration(
              color: Colors.
```


## License: unknown
https://github.com/troublecatcher/basketball/blob/f55c61c55e0793268c37ebcdf13a47d862ebf3c6/lib/screens/notes.dart

```
EdgeInsets.all(20),
            decoration: const BoxDecoration(
              color: Colors.
```


## License: MIT
https://github.com/ekokratos/reshipi-book/blob/b5d9cfff0fe0d577a1dd63099cf7679fcc95dd25/lib/features/recipe_edit/widgets/recipe_bottom_sheet.dart

```
EdgeInsets.all(20),
            decoration: const BoxDecoration(
              color: Colors.white,
              border
```


## License: unknown
https://github.com/troublecatcher/basketball/blob/f55c61c55e0793268c37ebcdf13a47d862ebf3c6/lib/screens/notes.dart

```
EdgeInsets.all(20),
            decoration: const BoxDecoration(
              color: Colors.white,
              border
```


## License: MIT
https://github.com/ekokratos/reshipi-book/blob/b5d9cfff0fe0d577a1dd63099cf7679fcc95dd25/lib/features/recipe_edit/widgets/recipe_bottom_sheet.dart

```
EdgeInsets.all(20),
            decoration: const BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.
```


## License: unknown
https://github.com/troublecatcher/basketball/blob/f55c61c55e0793268c37ebcdf13a47d862ebf3c6/lib/screens/notes.dart

```
EdgeInsets.all(20),
            decoration: const BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.
```


## License: MIT
https://github.com/ekokratos/reshipi-book/blob/b5d9cfff0fe0d577a1dd63099cf7679fcc95dd25/lib/features/recipe_edit/widgets/recipe_bottom_sheet.dart

```
EdgeInsets.all(20),
            decoration: const BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.only(
                topLeft
```


## License: unknown
https://github.com/troublecatcher/basketball/blob/f55c61c55e0793268c37ebcdf13a47d862ebf3c6/lib/screens/notes.dart

```
EdgeInsets.all(20),
            decoration: const BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.only(
                topLeft
```


## License: MIT
https://github.com/ekokratos/reshipi-book/blob/b5d9cfff0fe0d577a1dd63099cf7679fcc95dd25/lib/features/recipe_edit/widgets/recipe_bottom_sheet.dart

```
EdgeInsets.all(20),
            decoration: const BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.only(
                topLeft: Radius.circular
```


## License: unknown
https://github.com/troublecatcher/basketball/blob/f55c61c55e0793268c37ebcdf13a47d862ebf3c6/lib/screens/notes.dart

```
EdgeInsets.all(20),
            decoration: const BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.only(
                topLeft: Radius.circular
```


## License: MIT
https://github.com/ekokratos/reshipi-book/blob/b5d9cfff0fe0d577a1dd63099cf7679fcc95dd25/lib/features/recipe_edit/widgets/recipe_bottom_sheet.dart

```
EdgeInsets.all(20),
            decoration: const BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.only(
                topLeft: Radius.circular(20),
                
```


## License: unknown
https://github.com/troublecatcher/basketball/blob/f55c61c55e0793268c37ebcdf13a47d862ebf3c6/lib/screens/notes.dart

```
EdgeInsets.all(20),
            decoration: const BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.only(
                topLeft: Radius.circular(20),
                
```


## License: MIT
https://github.com/ekokratos/reshipi-book/blob/b5d9cfff0fe0d577a1dd63099cf7679fcc95dd25/lib/features/recipe_edit/widgets/recipe_bottom_sheet.dart

```
EdgeInsets.all(20),
            decoration: const BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.only(
                topLeft: Radius.circular(20),
                topRight: Radius
```


## License: unknown
https://github.com/troublecatcher/basketball/blob/f55c61c55e0793268c37ebcdf13a47d862ebf3c6/lib/screens/notes.dart

```
EdgeInsets.all(20),
            decoration: const BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.only(
                topLeft: Radius.circular(20),
                topRight: Radius
```


## License: MIT
https://github.com/ekokratos/reshipi-book/blob/b5d9cfff0fe0d577a1dd63099cf7679fcc95dd25/lib/features/recipe_edit/widgets/recipe_bottom_sheet.dart

```
EdgeInsets.all(20),
            decoration: const BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.only(
                topLeft: Radius.circular(20),
                topRight: Radius.circular(20),
```


## License: unknown
https://github.com/troublecatcher/basketball/blob/f55c61c55e0793268c37ebcdf13a47d862ebf3c6/lib/screens/notes.dart

```
EdgeInsets.all(20),
            decoration: const BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.only(
                topLeft: Radius.circular(20),
                topRight: Radius.circular(20),
```


## License: MIT
https://github.com/ekokratos/reshipi-book/blob/b5d9cfff0fe0d577a1dd63099cf7679fcc95dd25/lib/features/recipe_edit/widgets/recipe_bottom_sheet.dart

```
EdgeInsets.all(20),
            decoration: const BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.only(
                topLeft: Radius.circular(20),
                topRight: Radius.circular(20),
              ),
            
```


## License: unknown
https://github.com/troublecatcher/basketball/blob/f55c61c55e0793268c37ebcdf13a47d862ebf3c6/lib/screens/notes.dart

```
EdgeInsets.all(20),
            decoration: const BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.only(
                topLeft: Radius.circular(20),
                topRight: Radius.circular(20),
              ),
            
```


## License: MIT
https://github.com/ekokratos/reshipi-book/blob/b5d9cfff0fe0d577a1dd63099cf7679fcc95dd25/lib/features/recipe_edit/widgets/recipe_bottom_sheet.dart

```
EdgeInsets.all(20),
            decoration: const BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.only(
                topLeft: Radius.circular(20),
                topRight: Radius.circular(20),
              ),
            ),
            child:
```


## License: unknown
https://github.com/troublecatcher/basketball/blob/f55c61c55e0793268c37ebcdf13a47d862ebf3c6/lib/screens/notes.dart

```
EdgeInsets.all(20),
            decoration: const BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.only(
                topLeft: Radius.circular(20),
                topRight: Radius.circular(20),
              ),
            ),
            child:
```


## License: MIT
https://github.com/ekokratos/reshipi-book/blob/b5d9cfff0fe0d577a1dd63099cf7679fcc95dd25/lib/features/recipe_edit/widgets/recipe_bottom_sheet.dart

```
EdgeInsets.all(20),
            decoration: const BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.only(
                topLeft: Radius.circular(20),
                topRight: Radius.circular(20),
              ),
            ),
            child: Column(
              main
```


## License: unknown
https://github.com/troublecatcher/basketball/blob/f55c61c55e0793268c37ebcdf13a47d862ebf3c6/lib/screens/notes.dart

```
EdgeInsets.all(20),
            decoration: const BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.only(
                topLeft: Radius.circular(20),
                topRight: Radius.circular(20),
              ),
            ),
            child: Column(
              main
```


## License: MIT
https://github.com/ekokratos/reshipi-book/blob/b5d9cfff0fe0d577a1dd63099cf7679fcc95dd25/lib/features/recipe_edit/widgets/recipe_bottom_sheet.dart

```
EdgeInsets.all(20),
            decoration: const BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.only(
                topLeft: Radius.circular(20),
                topRight: Radius.circular(20),
              ),
            ),
            child: Column(
              mainAxisSize: MainAxis
```


## License: unknown
https://github.com/troublecatcher/basketball/blob/f55c61c55e0793268c37ebcdf13a47d862ebf3c6/lib/screens/notes.dart

```
EdgeInsets.all(20),
            decoration: const BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.only(
                topLeft: Radius.circular(20),
                topRight: Radius.circular(20),
              ),
            ),
            child: Column(
              mainAxisSize: MainAxis
```


## License: MIT
https://github.com/ekokratos/reshipi-book/blob/b5d9cfff0fe0d577a1dd63099cf7679fcc95dd25/lib/features/recipe_edit/widgets/recipe_bottom_sheet.dart

```
EdgeInsets.all(20),
            decoration: const BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.only(
                topLeft: Radius.circular(20),
                topRight: Radius.circular(20),
              ),
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
```


## License: unknown
https://github.com/troublecatcher/basketball/blob/f55c61c55e0793268c37ebcdf13a47d862ebf3c6/lib/screens/notes.dart

```
EdgeInsets.all(20),
            decoration: const BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.only(
                topLeft: Radius.circular(20),
                topRight: Radius.circular(20),
              ),
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
```


## License: MIT
https://github.com/ekokratos/reshipi-book/blob/b5d9cfff0fe0d577a1dd63099cf7679fcc95dd25/lib/features/recipe_edit/widgets/recipe_bottom_sheet.dart

```
EdgeInsets.all(20),
            decoration: const BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.only(
                topLeft: Radius.circular(20),
                topRight: Radius.circular(20),
              ),
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children
```


## License: unknown
https://github.com/troublecatcher/basketball/blob/f55c61c55e0793268c37ebcdf13a47d862ebf3c6/lib/screens/notes.dart

```
EdgeInsets.all(20),
            decoration: const BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.only(
                topLeft: Radius.circular(20),
                topRight: Radius.circular(20),
              ),
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children
```


## License: MIT
https://github.com/ekokratos/reshipi-book/blob/b5d9cfff0fe0d577a1dd63099cf7679fcc95dd25/lib/features/recipe_edit/widgets/recipe_bottom_sheet.dart

```
EdgeInsets.all(20),
            decoration: const BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.only(
                topLeft: Radius.circular(20),
                topRight: Radius.circular(20),
              ),
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container
```


## License: unknown
https://github.com/troublecatcher/basketball/blob/f55c61c55e0793268c37ebcdf13a47d862ebf3c6/lib/screens/notes.dart

```
EdgeInsets.all(20),
            decoration: const BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.only(
                topLeft: Radius.circular(20),
                topRight: Radius.circular(20),
              ),
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container
```


## License: MIT
https://github.com/ekokratos/reshipi-book/blob/b5d9cfff0fe0d577a1dd63099cf7679fcc95dd25/lib/features/recipe_edit/widgets/recipe_bottom_sheet.dart

```
EdgeInsets.all(20),
            decoration: const BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.only(
                topLeft: Radius.circular(20),
                topRight: Radius.circular(20),
              ),
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  width
```


## License: unknown
https://github.com/troublecatcher/basketball/blob/f55c61c55e0793268c37ebcdf13a47d862ebf3c6/lib/screens/notes.dart

```
EdgeInsets.all(20),
            decoration: const BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.only(
                topLeft: Radius.circular(20),
                topRight: Radius.circular(20),
              ),
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  width
```


## License: MIT
https://github.com/ekokratos/reshipi-book/blob/b5d9cfff0fe0d577a1dd63099cf7679fcc95dd25/lib/features/recipe_edit/widgets/recipe_bottom_sheet.dart

```
EdgeInsets.all(20),
            decoration: const BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.only(
                topLeft: Radius.circular(20),
                topRight: Radius.circular(20),
              ),
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  width: 
```


## License: unknown
https://github.com/troublecatcher/basketball/blob/f55c61c55e0793268c37ebcdf13a47d862ebf3c6/lib/screens/notes.dart

```
EdgeInsets.all(20),
            decoration: const BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.only(
                topLeft: Radius.circular(20),
                topRight: Radius.circular(20),
              ),
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  width: 
```


## License: MIT
https://github.com/ekokratos/reshipi-book/blob/b5d9cfff0fe0d577a1dd63099cf7679fcc95dd25/lib/features/recipe_edit/widgets/recipe_bottom_sheet.dart

```
EdgeInsets.all(20),
            decoration: const BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.only(
                topLeft: Radius.circular(20),
                topRight: Radius.circular(20),
              ),
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  width: 40,
                  height
```


## License: unknown
https://github.com/troublecatcher/basketball/blob/f55c61c55e0793268c37ebcdf13a47d862ebf3c6/lib/screens/notes.dart

```
EdgeInsets.all(20),
            decoration: const BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.only(
                topLeft: Radius.circular(20),
                topRight: Radius.circular(20),
              ),
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  width: 40,
                  height
```


## License: MIT
https://github.com/ekokratos/reshipi-book/blob/b5d9cfff0fe0d577a1dd63099cf7679fcc95dd25/lib/features/recipe_edit/widgets/recipe_bottom_sheet.dart

```
EdgeInsets.all(20),
            decoration: const BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.only(
                topLeft: Radius.circular(20),
                topRight: Radius.circular(20),
              ),
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  width: 40,
                  height: 4,
```


## License: unknown
https://github.com/troublecatcher/basketball/blob/f55c61c55e0793268c37ebcdf13a47d862ebf3c6/lib/screens/notes.dart

```
EdgeInsets.all(20),
            decoration: const BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.only(
                topLeft: Radius.circular(20),
                topRight: Radius.circular(20),
              ),
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  width: 40,
                  height: 4,
```


## License: MIT
https://github.com/ekokratos/reshipi-book/blob/b5d9cfff0fe0d577a1dd63099cf7679fcc95dd25/lib/features/recipe_edit/widgets/recipe_bottom_sheet.dart

```
EdgeInsets.all(20),
            decoration: const BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.only(
                topLeft: Radius.circular(20),
                topRight: Radius.circular(20),
              ),
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  width: 40,
                  height: 4,
                  decoration: Box
```


## License: unknown
https://github.com/troublecatcher/basketball/blob/f55c61c55e0793268c37ebcdf13a47d862ebf3c6/lib/screens/notes.dart

```
EdgeInsets.all(20),
            decoration: const BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.only(
                topLeft: Radius.circular(20),
                topRight: Radius.circular(20),
              ),
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  width: 40,
                  height: 4,
                  decoration: Box
```


## License: MIT
https://github.com/ekokratos/reshipi-book/blob/b5d9cfff0fe0d577a1dd63099cf7679fcc95dd25/lib/features/recipe_edit/widgets/recipe_bottom_sheet.dart

```
EdgeInsets.all(20),
            decoration: const BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.only(
                topLeft: Radius.circular(20),
                topRight: Radius.circular(20),
              ),
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  width: 40,
                  height: 4,
                  decoration: BoxDecoration(
```


## License: unknown
https://github.com/troublecatcher/basketball/blob/f55c61c55e0793268c37ebcdf13a47d862ebf3c6/lib/screens/notes.dart

```
EdgeInsets.all(20),
            decoration: const BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.only(
                topLeft: Radius.circular(20),
                topRight: Radius.circular(20),
              ),
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  width: 40,
                  height: 4,
                  decoration: BoxDecoration(
```

